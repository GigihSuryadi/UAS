<h1>Selamat Datang di <?=$nm?></h1>
 <h3>   Pengelolaan web Berita Terkini.com </h3>



